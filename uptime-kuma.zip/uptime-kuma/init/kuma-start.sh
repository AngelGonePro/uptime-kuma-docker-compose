#!/bin/sh
# Container entrypoint (runs under the image's own dumb-init).
# 1. Apply the admin login + trust proxy from .env to the database.
# 2. Start Uptime Kuma exactly as the image normally does.
# If step 1 fails (e.g. a too-weak password), the container stops with the
# reason in its log instead of starting with an unexpected login.
set -e
cd /app
node /kuma-init/kuma-admin.js
exec node server/server.js
