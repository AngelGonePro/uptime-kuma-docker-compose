# Uptime Kuma (Docker Compose)

Uptime Kuma 2.x, pinned, with:

- **Admin login from `.env`** — applied before Kuma starts, every start. A fresh
  install never shows Kuma's "create admin" page; an existing install keeps all
  monitors, status pages, notifications, 2FA and settings and only gets the
  username/password from `.env`.
- **Deploys on top of an existing install** — reuses its `uptime-kuma-data`
  folder and `uptime-kuma` container name; the old `docker-compose.yml` is kept as
  `docker-compose.yml.pre-stack`.
- **CPU / RAM / process limits**, no swap, Node heap capped under the limit, small logs.
- **Trust proxy** set from `.env`, so Kuma sees visitors' real IPs behind nginx /
  Cloudflare Tunnel.
- `update.sh` — pull, check `.env`, back up data before a version change, start,
  verify, **roll back** (version + data) and alert if it fails.

Everything configurable is in `.env`.

## Install

### On top of an existing Uptime Kuma (e.g. `~/status-uptimekuma`)

```
cd ~ && \
curl -fsSL -o /tmp/kuma.zip https://github.com/AngelGonePro/uptime-kuma-docker-compose/raw/refs/heads/main/uptime-kuma.zip && \
python3 -c "import zipfile; open('/tmp/deploy-update.sh','wb').write(zipfile.ZipFile('/tmp/kuma.zip').read('uptime-kuma/deploy-update.sh'))" && \
sh /tmp/deploy-update.sh https://github.com/AngelGonePro/uptime-kuma-docker-compose/raw/refs/heads/main/uptime-kuma.zip status-uptimekuma && \
cp /tmp/deploy-update.sh status-uptimekuma/ && chmod +x status-uptimekuma/*.sh && rm -f /tmp/kuma.zip /tmp/deploy-update.sh
```

Then set the admin login and start it:

```
nano ~/status-uptimekuma/.env
cd ~/status-uptimekuma && ./update.sh
```

`update.sh` stops Kuma for a few seconds to back up `uptime-kuma-data` to
`backups/` (because the image changes from the old floating tag to the pinned
version), then starts the new container on the same data.

### Fresh install

Same command with `uptime-kuma` in place of both `status-uptimekuma`s, then
`nano ~/uptime-kuma/.env` and `cd ~/uptime-kuma && ./update.sh`.

## Update later

```
cd ~/status-uptimekuma
./deploy-update.sh https://github.com/AngelGonePro/uptime-kuma-docker-compose/raw/refs/heads/main/uptime-kuma.zip .
./update.sh
```

`deploy-update.sh` never touches `.env`, `uptime-kuma-data/`, `backups/` or files
you've edited, and appends any new `.env` keys at the bottom. New Kuma release:
set `KUMA_VERSION` in `.env` and run `./update.sh`.

## Changing the admin login

Edit `KUMA_ADMIN_USERNAME` / `KUMA_ADMIN_PASSWORD` in `.env`, run `./update.sh`.
The password must pass Kuma's own strength rule (8+ characters mixing
upper/lowercase, numbers or symbols); `update.sh` checks this first and changes
nothing if it fails. A new password signs out existing sessions. Leave both empty
to never touch the account.

If you change the password in Kuma's web UI, change it in `.env` too — otherwise
the `.env` one is put back on the next start.

## nginx (Linode, Cloudflare Tunnel on port 80)

The two site configs are separate from this zip:

- `status.cosmoscraft.net.conf` — public status page only. Admin pages,
  login, socket.io and `/metrics` answer 404.
- `statuss.cosmoscraft.net.conf` — the full admin UI (with WebSocket).

In nginx-ui: Manage Sites → Add → "Skip for now" at the cert step → paste each.
Point both tunnel hostnames at the Linode's nginx on port 80.

Then in Kuma (at statuss.cosmoscraft.net): open the status page → Edit Status
Page → **Domain Names** → add `status.cosmoscraft.net` → Save. After that
`https://status.cosmoscraft.net/` shows that page directly.

On the Linode, nginx-ui uses host networking and reaches Kuma at
`127.0.0.1:3001`, so you can set `KUMA_BIND=127.0.0.1` in `.env` to keep the
admin UI off the public IP (`45.79.25.46:3001`).

## Resource limits

Defaults: 256 MB RAM (no swap), 0.5 CPU, 256 processes, Node heap 128 MB.
Measured on 2.5.9 with 71 monitors at 20 s intervals plus status page traffic:
about 112–125 MB RAM, under 3% CPU most of the time, no OOM kills.

If the host also sets per-container limits at boot (e.g. a `docker update`
script), remove or update its `uptime-kuma` entry, or it will override these.

## Files

| File | What it does |
|---|---|
| `docker-compose.yml` | The Kuma container, limits, healthcheck |
| `.env` | All settings |
| `init/kuma-start.sh` | Entrypoint: applies `.env` admin login, then starts Kuma |
| `init/kuma-admin.js` | The admin / trust-proxy step (uses Kuma's own code) |
| `update.sh` | Start / update / verify / roll back |
| `deploy-update.sh` | Pull a new release zip without clobbering your files |

Logs: `update.log`. A failed update's data is kept as
`uptime-kuma-data.failed-<version>-<time>` next to the restored one.
