// Runs inside the Uptime Kuma container before the server starts (kuma-start.sh).
//
// Applies the admin login and the trust-proxy setting from .env to the
// database, then exits so the normal server starts on an already-set-up
// database. Because this happens before the server boots, a fresh install never
// shows Kuma's "create admin" page, and a redeploy on top of an existing
// install keeps every monitor, status page, notification and setting — only
// the admin username/password (and trust proxy) are brought in line with .env.
//
//   node kuma-admin.js           apply (used by kuma-start.sh)
//   node kuma-admin.js --check   validate the .env values only, touch nothing
"use strict";

process.chdir("/app");
const { createRequire } = require("module");
const appRequire = createRequire("/app/server/server.js");

const fs = require("fs");
const path = require("path");

const USERNAME = (process.env.KUMA_ADMIN_USERNAME || "").trim();
const PASSWORD = process.env.KUMA_ADMIN_PASSWORD || "";
const TRUST_PROXY = (process.env.KUMA_TRUST_PROXY || "").trim().toLowerCase();
const CHECK_ONLY = process.argv.includes("--check");

const say = (m) => console.log(`[kuma-admin] ${m}`);
const fail = (m) => {
    console.error(`[kuma-admin] ERROR: ${m}`);
    process.exit(1);
};

function validate() {
    if (!USERNAME && !PASSWORD) {
        return false; // nothing set: leave the accounts exactly as they are
    }
    if (!USERNAME || !PASSWORD) {
        fail("set both KUMA_ADMIN_USERNAME and KUMA_ADMIN_PASSWORD in .env (or leave both empty)");
    }
    if (USERNAME.length > 255) {
        fail("KUMA_ADMIN_USERNAME is longer than 255 characters");
    }
    // Same rule Uptime Kuma's own setup / change-password pages use.
    const { passwordStrength } = appRequire("check-password-strength");
    if (passwordStrength(PASSWORD).value === "Too weak") {
        fail(
            "KUMA_ADMIN_PASSWORD is too weak for Uptime Kuma (it needs at least 8 characters " +
                "mixing upper/lowercase letters, numbers or symbols)"
        );
    }
    if (!["", "true", "false"].includes(TRUST_PROXY)) {
        fail(`KUMA_TRUST_PROXY must be true, false or empty, not "${TRUST_PROXY}"`);
    }
    return true;
}

async function main() {
    const wantAdmin = validate();
    if (CHECK_ONLY) {
        say(wantAdmin ? "admin settings in .env look OK" : "admin login not set in .env (accounts left as they are)");
        return;
    }

    const Database = appRequire("./database");
    const { R } = appRequire("redbean-node");
    const passwordHash = appRequire("./password-hash");
    const { Settings } = appRequire("./settings");

    Database.initDataDir({});

    // Fresh install: pick SQLite so Kuma skips its "choose a database" page.
    // Existing installs already have db-config.json (or a kuma.db, which Kuma
    // itself turns into db-config.json) and are left alone.
    const dbConfigPath = path.join(Database.dataDir, "db-config.json");
    if (!fs.existsSync(dbConfigPath) && !process.env.UPTIME_KUMA_DB_TYPE) {
        Database.writeDBConfig({ type: "sqlite" });
        say("fresh install: using SQLite");
    }

    await Database.connect(false, false, true);
    // Same migrations the server runs at startup; when the server runs them
    // again right after this, they are already done and cost nothing.
    const port = parseInt(process.env.UPTIME_KUMA_PORT || process.env.PORT || "3001", 10);
    await Database.patch(port, process.env.UPTIME_KUMA_HOST || undefined);

    if (wantAdmin) {
        const users = await R.getAll("SELECT id, username, password FROM `user` ORDER BY id");
        if (users.length === 0) {
            await R.exec("INSERT INTO `user` (username, password, active) VALUES (?, ?, 1)", [
                USERNAME,
                await passwordHash.generate(PASSWORD),
            ]);
            say(`created admin "${USERNAME}"`);
        } else {
            // Uptime Kuma has one login. Keep that account (its 2FA, timezone
            // and everything it owns) and only update its name and password.
            const admin = users[0];
            const changes = [];
            if (admin.username !== USERNAME) {
                const clash = users.find((u) => u.id !== admin.id && u.username === USERNAME);
                if (clash) {
                    fail(`another account (id ${clash.id}) is already named "${USERNAME}"`);
                }
                await R.exec("UPDATE `user` SET username = ? WHERE id = ?", [USERNAME, admin.id]);
                changes.push(`username "${admin.username}" -> "${USERNAME}"`);
            }
            // Only re-hash when the password really changed, so restarts don't
            // log everyone out.
            if (!passwordHash.verify(PASSWORD, admin.password) || passwordHash.needRehash(admin.password)) {
                await R.exec("UPDATE `user` SET password = ? WHERE id = ?", [
                    await passwordHash.generate(PASSWORD),
                    admin.id,
                ]);
                changes.push("password updated");
            }
            await R.exec("UPDATE `user` SET active = 1 WHERE id = ? AND active = 0", [admin.id]);
            say(changes.length ? `admin: ${changes.join(", ")} (old sessions are signed out)` : `admin "${USERNAME}" already up to date`);
        }
    } else {
        say("KUMA_ADMIN_USERNAME / KUMA_ADMIN_PASSWORD empty: accounts left as they are");
    }

    if (TRUST_PROXY) {
        const want = TRUST_PROXY === "true";
        if ((await Settings.get("trustProxy")) !== want) {
            await Settings.set("trustProxy", want, "general");
            say(`trust proxy set to ${want}`);
        }
    }

    await Database.close();
    say("OK");
}

main()
    .then(() => process.exit(0)) // Settings keeps a cache timer running; don't wait on it
    .catch((e) => fail(e && e.stack ? e.stack : String(e)));
