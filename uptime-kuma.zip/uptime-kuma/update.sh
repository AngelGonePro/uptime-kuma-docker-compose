#!/usr/bin/env bash
# Starts or updates Uptime Kuma at the version pinned in .env, verifies it, and
# rolls back + alerts if it doesn't come up healthy.
#
#   ./update.sh     first start, after deploy-update.sh, after a version bump,
#                   or after changing anything in .env (admin login, limits...)
#
# Before a version change, Kuma is stopped briefly and its data folder is backed
# up to backups/ (a newer version may migrate the database). If the new version
# fails its checks, the old version AND that backup are restored.
set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"

LOG=./update.log
STATE=./.update-state   # last version that passed verification
log() { printf '%s %s\n' "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" "$*" | tee -a "$LOG"; }

envval() { sed -n "s/^$1=//p" .env | tail -n1 | sed 's/[[:space:]]*#.*$//; s/^"\(.*\)"$/\1/; s/^'"'"'\(.*\)'"'"'$/\1/'; }
VERSION=$(envval KUMA_VERSION)
DATA=$(envval KUMA_DATA_DIR); DATA=${DATA:-./uptime-kuma-data}
CNAME=$(envval KUMA_CONTAINER_NAME); CNAME=${CNAME:-uptime-kuma}
TIMEOUT=$(envval UPDATE_HEALTH_TIMEOUT); TIMEOUT=${TIMEOUT:-600}
WEBHOOK=$(envval UPDATE_ALERT_WEBHOOK)
KEEP=$(envval BACKUPS_KEEP); KEEP=${KEEP:-2}
[ -n "$VERSION" ] || { log "KUMA_VERSION is empty in .env"; exit 1; }

alert() {
  log "ALERT: $1"
  [ -n "$WEBHOOK" ] || return 0
  if [[ "$WEBHOOK" == *discord.com/api/webhooks* ]]; then
    curl -fsS -m 15 -H 'Content-Type: application/json' \
      -d "{\"content\": \"⚠️ uptime-kuma ($(hostname)): ${1//\"/\\\"}\"}" "$WEBHOOK" >/dev/null || log "webhook send failed"
  else
    curl -fsS -m 15 -d "uptime-kuma ($(hostname)): $1" "$WEBHOOK" >/dev/null || log "webhook send failed"
  fi
}

health() { docker inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{else}}{{.State.Status}}{{end}}' "$CNAME" 2>/dev/null || echo missing; }

verify() {
  local deadline=$((SECONDS + TIMEOUT)) st
  while (( SECONDS < deadline )); do
    st=$(health)
    if [ "$st" = healthy ]; then
      local since
      since=$(docker inspect -f '{{.State.StartedAt}}' "$CNAME" 2>/dev/null || true)
      log "verify: $CNAME healthy — $(docker logs ${since:+--since "$since"} "$CNAME" 2>&1 | grep '\[kuma-admin\]' | grep -v ' OK$' | tail -n 3 | tr '\n' ' ')"
      return 0
    fi
    # The admin step failed (exits the container) — no point waiting.
    if docker logs --tail 50 "$CNAME" 2>&1 | grep -q '\[kuma-admin\] ERROR'; then
      log "verify failed: admin step reported an error"
      break
    fi
    sleep 5
  done
  log "verify failed (container is $(health))"
  docker logs --tail 25 "$CNAME" 2>&1 | sed "s/^/  $CNAME: /" | tee -a "$LOG" || true
  return 1
}

backup_data() {
  mkdir -p backups
  local f="backups/data-$1-$(date -u +%Y%m%dT%H%M%SZ).tar.gz"
  tar -C "$(dirname "$DATA")" -czf "$f" "$(basename "$DATA")"
  ls -1t backups/data-*.tar.gz 2>/dev/null | tail -n +"$((KEEP + 1))" | xargs -r rm -f
  echo "$f"
}

log "=== update start: Uptime Kuma $VERSION ==="
mkdir -p "$DATA"
running=$(docker inspect -f '{{.Config.Image}}' "$CNAME" 2>/dev/null | sed 's/.*://' || true)

# Pull first, while the current version keeps running.
if ! docker compose pull 2>&1 | tee -a "$LOG"; then
  alert "could not pull louislam/uptime-kuma:$VERSION; nothing changed"
  exit 1
fi

# Check the admin login in .env with the new image before touching anything.
if ! out=$(docker compose run --rm --no-deps -T --entrypoint node uptime-kuma /kuma-init/kuma-admin.js --check 2>&1); then
  printf '%s\n' "$out" | tee -a "$LOG"
  log "fix .env as shown above, then run ./update.sh again (nothing was changed)"
  exit 1
fi
printf '%s\n' "$out" | grep '\[kuma-admin\]' | tee -a "$LOG"

backup=""
if [ -n "$running" ] && [ "$running" != "$VERSION" ] && [ -f "$DATA/kuma.db" ]; then
  log "switching Uptime Kuma $running -> $VERSION; stopping it briefly to back up its data"
  docker stop -t 60 "$CNAME" 2>&1 | tee -a "$LOG" || true
  backup=$(backup_data "$running")
  log "data backed up to $backup"
fi

docker compose up -d --remove-orphans 2>&1 | tee -a "$LOG" || true   # verify() decides

if verify; then
  echo "$VERSION" > "$STATE"
  docker image prune -f >/dev/null
  log "=== update OK: Uptime Kuma $VERSION ==="
  exit 0
fi

# ── rollback ──
if [ -n "$backup" ] && [ -n "$running" ]; then
  log "rolling back to Uptime Kuma $running and restoring its data backup"
  docker compose stop 2>&1 | tee -a "$LOG" || true
  mv "$DATA" "$DATA.failed-$VERSION-$(date -u +%Y%m%dT%H%M%SZ)"
  tar -C "$(dirname "$DATA")" -xzf "$backup"
  sed -i "s/^KUMA_VERSION=.*/KUMA_VERSION=$running/" .env
  docker compose up -d --remove-orphans 2>&1 | tee -a "$LOG" || true
  if verify; then
    alert "update to Uptime Kuma $VERSION failed verification — rolled back to $running, which is running again. Check $LOG."
  else
    alert "update to Uptime Kuma $VERSION failed AND the rollback failed — Uptime Kuma may be down. Check $LOG."
  fi
else
  alert "Uptime Kuma $VERSION did not come up healthy (no version change to roll back). Check $LOG."
fi
exit 1
